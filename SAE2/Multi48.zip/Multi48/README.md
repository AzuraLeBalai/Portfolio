Multi48
===========

Développé par Joshua COLLIN
Contact : joshua.collin@univ-lille.fr

# Présentation de Multi48

Logiciel proposant de faire le plus grand score en déplacent les cases de manière horizontal et vertical et en les ajoutant lorsque deux cases identiques entre en collision. Le tout en validant chaque déplacement par une question de mathématique plus ou moins complexe selon la difficulté choisis en début de partie


# Utilisation de Multi48

Afin d'utiliser le projet, il suffit de taper les commandes suivantes dans un terminal en ce plaçant dans le dossier nommé « Multi48 »:

```
./compile.sh
```
Permet la compilation des fichiers présents dans 'src' et création des fichiers '.class' dans 'classes'

```
./run.sh Multi48
```
Permet le lancement du jeu

Des screenshot sont disponibles comme exemples dans le dossier shots
