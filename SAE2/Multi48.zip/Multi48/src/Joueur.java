class Joueur{
    String Nom_Joueur;
    int nb_vie;
    int score;
    int limite;
}