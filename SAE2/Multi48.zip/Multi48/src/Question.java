class Question{
    Type_calcul type;
    int nb1;
    int nb2;
}