class Partie{
    String niveau;  //CP = addition et soustraction de 1 à 10
                    //CE1 = addition et soustraction de 1 à 1000 et multiplication jusqu'a 9
                    //CE2
                    //CM1
                    //CM2
}