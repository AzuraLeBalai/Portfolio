class Case {
    Type type;
    int num;
}