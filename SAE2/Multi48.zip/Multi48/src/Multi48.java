import extensions.CSVFile;
import extensions.File;

class Multi48 extends Program{

    ////////////////////////////// Variable //////////////////////////////
    //Défini la taille de la grille
    final int NB_COLS = 4;
    final int NB_LIGNES = 4;

    //Défini les proba d'apparition des 2 et des 1
    final double PROBA_2 = 0.80;
    final double PROBA_4 = 0.20;
    //Défini le temps de pause et le chemin ou trouver les images game over et multi48
    final int TEMPS_PAUSE = 1500;
    final String GAMEOVER = "../ressources/gameover.txt";
    final String multi48 = "../ressources/multi48.txt";

    //Défini les codes couleur principaux
    public  static  final  String 	RED = "\u001B[31m" ;
    public  static  final  String 	CYAN = "\u001B[36m" ;
    public  static  final  String WHITE = "\u001B[37m" ;
    public  static  final  String 	JAUNE = "\u001B[33m" ;
    public  static  final  String 	MAGENTA = "\u001B[35m";
    
    //Boolean pour vérifier si la partiee est fini
    boolean partie_fini = false;

    //Défini le meilleur score du joueur qui joue actuellement
    int highScore = 0;

    //Défini les règle
    String Regle = RED + "Voici les règles:"+ WHITE +"\nTu joues dans une grille de quatre par quatre et ton objectif est de faire \napparaître le nombre 2048 dans cette grille pour gagner \nPour cela, tu peux déplacer toutes les cases de la grille dans 4 directions : \n"+RED+"Haut = "+JAUNE+" Z "+WHITE+" \n"+RED+"Bas = "+JAUNE+"S"+WHITE+" \n"+RED+"Gauche = "+JAUNE+"Q"+WHITE+" \n"+RED+"Droite = "+JAUNE+"D"+WHITE+" en minuscule ou majuscule\nPar exemple si tu joues la direction droite, les cases iront le plus à droite possible pour ne pas laisser de vide \nAvant de valider ton déplacement, une question mathématique te sera posée, si tu as bon, le déplacement est validé \nSinon les cases ne bougent pas et une nouvelle case 2 ou 4 apparaît \nEnsuite si deux cases sont identiques exemple deux cases 2, alors si tu rassembles les deux pour qu'elles aillent jusqu'à se rencontrer \nelles fusionnent et se transforment en une seule case deux fois plus grande, ici 4 \nAprès chaque déplacement valide ou non, un nombre apparaît aléatoirement sur une case vide \nSi tu n'arrives pas à faire le nombre 2048 et que ta grille est remplie et que plus aucun déplacement n'est possible \nc'est perdu :( \nEnfin, si tu fais un déplacement qui ne déplace aucune case, le déplacement ne sera pas pris en compte et tu devras en retaper un nouveau \n"+ RED+"Enfin si tu rentres "+JAUNE+ 'F'+RED+ " en direction, tu pourras quitter la partie \n Bonne Chance !" +WHITE ;


    ////////////////////////////// Creation classe //////////////////////////////

    //Créer une nouvelle case avec le type et numéro défini
    Case newCases( Type type, int num){
        Case cases = new Case();
        cases.type = type;
        cases.num = num;
        return cases;
    }

    //Créer une nouvelle case vide
    Case newVide(Case case_choisis){
        case_choisis.type = Type.VIDE;
        case_choisis.num = 1;
        return case_choisis;
    }

    //Créer une nouvelle case 2
    Case new2(Case case_choisis){
        case_choisis.type = Type.NOMBRE;
        case_choisis.num = 2;
        return case_choisis;
    }

    //Créer une nouvelle case 4
    Case new4(Case case_choisis){
        case_choisis.type = Type.NOMBRE;
        case_choisis.num = 4;
        return case_choisis;
    }

    //Créer une nouvelle partie
    Partie newPartie(){
        Partie partie = new Partie();
        partie.niveau = "";
        return partie;
    }

    //Créer une nouveau joueur
    Joueur newJoueur(){
        Joueur joueur = new Joueur();
        joueur.Nom_Joueur = "";
        clearScreen();
        println("Entrez votre nom");
        delay(TEMPS_PAUSE);
        joueur.Nom_Joueur = readString().toUpperCase();

        //On vérifie que le joueur ne rentre pas un nom vide
        while(length(joueur.Nom_Joueur) == 0){
            println (RED + "Tu dois mettre un nom !" + WHITE);
            joueur.Nom_Joueur = readString().toUpperCase();
        }
        clearScreen();
        println("");
        println ("Enchanté " + CYAN +joueur.Nom_Joueur + WHITE + " !");
        println("");
        delay(TEMPS_PAUSE);

        //On défini le score de départ du joueur créer son nombrede vie et la case maximum à atteindre
        joueur.nb_vie = 3;
        joueur.limite = 2048;
        joueur.score = 0;
        return joueur;
    }

    //On créer une nouvelle question
    Question newQuestion(){
        Question question = new Question();
        return question;
    }

    //On créer une nouvelle addition en fonction des nombres défini
    Question newAddition(Question addition,int nb1,int nb2){
        addition.type = Type_calcul.ADDITION;
        addition.nb1 = nb1;
        addition.nb2 = nb2;
        return addition;
    }

    //On créer une nouvelle soustraction en fonction des nombres défini
    Question newSoustraction(Question soustraction,int nb1,int nb2){
        soustraction.type = Type_calcul.SOUSTRACTION;
        //On vérifie les nombre de la soustraction pour que le résultat reste toujours positif
        if (nb1 < nb2){
            soustraction.nb1 = nb2;
            soustraction.nb2 = nb1;
        }else{
            soustraction.nb1 = nb1;
            soustraction.nb2 = nb2;
        }
        return soustraction;
    }

    //On créer une nouvelle multiplication en fonction des nombres défini
    Question newMultiplication(Question multiplication,int nb1,int nb2){
        multiplication.type = Type_calcul.MULTIPLICATION;
        multiplication.nb1 = nb1;
        multiplication.nb2 = nb2;
        return multiplication;
    }

    //On créer une nouvelle addition en fonction des nombres défini
    Question newDivision(Question division,int nb1,int nb2){
        division.type = Type_calcul.DIVISION;
        division.nb1 = nb1;
        division.nb2 = nb2;
        return division;
    }

    ////////////////////////////// Remplissage et génération de cases //////////////////////////////
    
    //On créer une grille remplie de case vide

    Case[][] creationGrilleVide(Case[][] grille){
        for(int i = 0; i < length(grille,1); i ++){
            for(int j = 0; j < length(grille,2); j ++){
                grille[i][j] = newCases(Type.VIDE,1) ;
            }
        }
        return grille;
    }

    
    //ApOn fait appraître de 2 cases de 2 dans la grille vide

    Case[][] initialiser(Case[][] grille){
        creationGrilleVide(grille);
        for (int i = 0; i < 2 ; i ++){
            int col = tirerAuHasard(NB_COLS);
            int lig = tirerAuHasard(NB_LIGNES);
            while((grille[lig][col]).num != 1){
                col = tirerAuHasard(NB_COLS);
                lig = tirerAuHasard(NB_LIGNES);
            }
            grille[lig][col].type = Type.NOMBRE;
            grille[lig][col].num = 2;
        }
        return grille;
    }
    
    //Tire un nombre au hasard en fonction de max
    int tirerAuHasard(int max){
        return (int) (random()*max) ;
    }


    //Fait apparaitre une case aléatoire sur un emplacement non vide de la grille
    Case[][] apparition_alea(Case[][] grille,Partie partie){
        int col = tirerAuHasard(NB_COLS);
        int lig = tirerAuHasard(NB_LIGNES);
        while((grille[lig][col]).num != 1){
            col = tirerAuHasard(NB_COLS);
            lig = tirerAuHasard(NB_LIGNES);
        }
        grille[lig][col] = creation_aleatoire(grille[lig][col],partie);
        return grille;
    }

    //Créer aléatoirement une case 2 ou 4 en fonction de leurs probabilité d'apparition sur une case vide
    Case creation_aleatoire(Case case_choisis,Partie partie){
        int proba = appliquer_proba(partie);
        if (proba == 2){
            case_choisis = new2(case_choisis);
        }
        else{
            case_choisis = new4(case_choisis);
        }
        return case_choisis;
    }

    
    //Renvoie 2 ou 4 en fonction de leurs probabilité d'apparition
    int appliquer_proba(Partie partie){
        int res = 0 ;
        double alea = random();
        if(alea <= PROBA_4){
            res = 4;
                }
        else{
            res = 2;
            }
        return res;
    }

    ////////////////////////////// QUESTION //////////////////////////////

    //On demande au joueur de choisir le niveau et on l'actualise dans la partie pour les question
    void niveau(Partie partie){
    String rep_niveau = readString().toUpperCase();
        println(""); 
        while(!rep_niveau.equals("CP") && !rep_niveau.equals("CE1") && !rep_niveau.equals("CE2") && !rep_niveau.equals("CM1") && !rep_niveau.equals("CM2")){
            println(RED + "Désolé, tu dois répondre " + JAUNE +"CP"+WHITE +"," +JAUNE +" CE1"+WHITE+ "," +JAUNE +" CE2" +WHITE+ "," +JAUNE +" CM1 " +WHITE +"ou" +JAUNE +" CM2 " + WHITE);
            rep_niveau = readString().toUpperCase();
        }
        partie.niveau = rep_niveau;
    }

    //Créer une question en fonction du niveau choisis
    Question Question_reponse(Partie partie){
        int max_addition = 0;
        int max_soustraction = 0;
        int max_division = 0;
        int max_multiplication = 0;
        int type_max = 0;
        Question question = newQuestion();

        //On défini les paramètrescelon le niveau choisis
        if (equals(partie.niveau,"CP")){
            max_addition = 6;
            type_max = 1;
        
        }else if (equals(partie.niveau,"CE1")){
            max_addition = 51;
            max_soustraction = 11;
            max_multiplication = 6;
            type_max = 2;
        
        }else if (equals(partie.niveau,"CE2")){
            max_addition = 251;
            max_soustraction = 101;
            max_multiplication = 11;
            type_max = 3;
        
        }else if (equals(partie.niveau,"CM1")){
            max_addition = 501;
            max_soustraction = 251;
            max_multiplication = 11;
            max_division = 6;
            type_max = 4;
        
        }else if (equals(partie.niveau,"CM2")){
            max_addition = 501;
            max_soustraction = 501;
            max_multiplication = 11;
            max_division = 10;
            type_max = 4;
        }

        //On créer une opérations celon le niveau et les nombres tiré au hasard
        type_max = tirerAuHasard(type_max);
        if(type_max == 0){
            question = newAddition(question,tirerAuHasard(max_addition),tirerAuHasard(max_addition));
        }
        
        else if(type_max == 1){
            question = newSoustraction(question,tirerAuHasard(max_soustraction),tirerAuHasard(max_soustraction));
        }
        else if(type_max == 2){
            question = newMultiplication(question,tirerAuHasard(max_multiplication),tirerAuHasard(max_multiplication));
        }
        else if(type_max == 3){
            question = newDivision(question,tirerAuHasard(max_division) + 1,tirerAuHasard(max_division) + 1);
            while(question.nb1 % question.nb2 != 0){
                question = newDivision(question,tirerAuHasard(max_division) + 1,tirerAuHasard(max_division) + 1);
            }
        } 
        return question;
    }

    //Vérifie que la réponse du joueur pour voir si c'est la bonne réponse à la question posé
    boolean reponse_correct(Question question){
        String reponse_joueur_test = "";
        int reponse_joueur;

        //On pose la question au joueur
        if (question.type == Type_calcul.ADDITION){
            println ("Combien font " +CYAN+ question.nb1 +WHITE+ " + " +CYAN+ question.nb2 +WHITE+ " ?");
            delay(TEMPS_PAUSE);
            reponse_joueur_test = readString();
            
            //On vérifie que la réponse du joueur est un nombre
            while(!chiffre_correct(reponse_joueur_test) || length(reponse_joueur_test) == 0){
                println(RED + "Tu dois rentrer un nombre !" + WHITE);
                delay(TEMPS_PAUSE);
                reponse_joueur_test = readString();
                println("");
            }
            //On teste la réponse du joueur et on vérifie si elle est  où non
            reponse_joueur = stringToInt(reponse_joueur_test);
                if (question.nb1 + question.nb2 == reponse_joueur){
                    return true;
                }

        //On pose la question au joueur
        }else if (question.type == Type_calcul.SOUSTRACTION){
            println ("Combien font " +CYAN+ question.nb1 +WHITE+ " - " +CYAN+ question.nb2 +WHITE+ " ?");
            delay(TEMPS_PAUSE);
            reponse_joueur_test = readString();

            //On vérifie que la réponse du joueur est un nombre
            while(!chiffre_correct(reponse_joueur_test) || length(reponse_joueur_test) == 0){
                println(RED + "Tu dois rentrer un nombre !" + WHITE);
                delay(TEMPS_PAUSE);
                reponse_joueur_test = readString();
                println("");
            }

            //On teste la réponse du joueur et on vérifie si elle est correct où non
            reponse_joueur = stringToInt(reponse_joueur_test);
            if (question.nb1 - question.nb2 == reponse_joueur){
                return true;
            }
        
        //On pose la question au joueur
        }else if (question.type == Type_calcul.MULTIPLICATION){
            println ("Combien font " + CYAN+ question.nb1 +WHITE+ " x " + CYAN+ question.nb2 +WHITE+ " ?");
            delay(TEMPS_PAUSE);
            reponse_joueur_test = readString();

            //On vérifie que la réponse du joueur est un nombre
            while(!chiffre_correct(reponse_joueur_test) || length(reponse_joueur_test) == 0){
                println(RED + "Tu dois rentrer un nombre !" + WHITE);
                delay(TEMPS_PAUSE);
                reponse_joueur_test = readString();
                println("");
            }

            //On teste la réponse du joueur et on vérifie si elle est correct où non
            reponse_joueur = stringToInt(reponse_joueur_test);
            if (question.nb1 * question.nb2 == reponse_joueur){
                return true;
            }
        

        //On pose la question au joueur
        }else if (question.type == Type_calcul.DIVISION){
            println ("Combien font " +CYAN  +question.nb1 +WHITE +  " % " +CYAN+ question.nb2 +WHITE+ " ?");
            delay(TEMPS_PAUSE);
            reponse_joueur_test = readString();

            //On vérifie que la réponse du joueur est un nombre
            while(!chiffre_correct(reponse_joueur_test) || length(reponse_joueur_test) == 0){
                println(RED + "Tu dois rentrer un nombre !" + WHITE);
                delay(TEMPS_PAUSE);
                reponse_joueur_test = readString();
                println("");
            }

            //On teste la réponse du joueur et on vérifie si elle est  où non
            reponse_joueur = stringToInt(reponse_joueur_test);
            if (question.nb1 / question.nb2 == reponse_joueur){
                return true;
            }
        }
        return false;
    }


    //On vérifie cacactère de la réponse du joueur pour vérifier que la réponse est bien un nombre
    boolean chiffre_correct(String reponse){
        boolean bool = true;
        for(int i = 0; i < length(reponse);i ++){
            if (charAt(reponse,i) >= '0' && charAt(reponse,i) <= '9'){
            }
            else{
                return false;
            }
        }
        return true;
    }


    //Calcul la bonne réponse à la question poser au joueur
    int Bonne_reponse(Question question){
        int rep = 0;
        if (question.type == Type_calcul.ADDITION){
            rep = question.nb1 + question.nb2;
        }
        else if (question.type == Type_calcul.SOUSTRACTION){
            rep = question.nb1 - question.nb2;
        }
        else if (question.type == Type_calcul.MULTIPLICATION){
            rep = question.nb1 * question.nb2;
        }
        else if (question.type == Type_calcul.DIVISION){
            rep = question.nb1 / question.nb2;
        }
        return rep;
    }

    ////////////////////////////// DEPLACEMENT //////////////////////////////

    //Fonction Principale de deplacement
    void deplacement(Case[][] grille, Joueur joueur, Partie partie) {

        //On demande la direction avec une aide pour savoir lesquelles sont valides
        delay(TEMPS_PAUSE);
        println("Donne moi une direction :)");
        println(RED+"Haut = "+JAUNE+" D "+WHITE+" \n "+RED+"Bas = "+JAUNE+"S"+WHITE+" \n "+RED+"Gauche = "+JAUNE+"Q"+WHITE+" \n "+RED+"Droite = "+JAUNE+"D"+ "\n" + RED + "Sauvegarder et quitter = " + JAUNE + "F" + WHITE);
        delay(TEMPS_PAUSE);
        String direction_test = readString().toLowerCase();
        println("");
        Question question = newQuestion();
        String reponse = "";

        //On vérifie que la direction ne contient qu'un seul caractère
        while(length(direction_test) == 0 ||length(direction_test) > 1){
            println(RED + "Tu dois rentrer un déplacement correct!" + WHITE);
            println(RED+"Haut = "+JAUNE+" D "+WHITE+" \n "+RED+"Bas = "+JAUNE+"S"+WHITE+" \n "+RED+"Gauche = "+JAUNE+"Q"+WHITE+" \n "+RED+"Droite = "+JAUNE+"D"+ "\n" + RED + "Sauvegarder et quitter = " + JAUNE + "F" + WHITE);
            delay(TEMPS_PAUSE);
            direction_test = readString().toLowerCase();
            println("");
            }

        //On transforme la direction en caractère pour faciliter les calcul
        char direction = charAt(direction_test,0);

        //Si la direction demandé est f, on demande confirmation
        if (direction == 'f'){
            println("Tu es sûr de vouloir finir la partie ? Réponds par" + JAUNE +  " oui " +WHITE + "ou par" +JAUNE + " non " + WHITE);
            delay(TEMPS_PAUSE);
            reponse = readString();

            //Tant que la réponse est incorrect, on redemande une réponse
            while(!reponse.equals("oui") && !reponse.equals("non") || length(reponse) == 0){
                println(RED + "Désolé, tu dois répondre par" + JAUNE +  " oui " +RED + "ou par" +JAUNE + " non " + WHITE);
                delay(TEMPS_PAUSE);
                reponse = readString();
            }

            //Si la confirmation est oui, on fait un dernier déplacement avant de quitter
            if (reponse.equals("oui")){
                partie_fini = true;
                println("Un dernier déplacement pour la route !");
                delay(TEMPS_PAUSE);
                direction_test = "" + readString();
                
                //On redemande une réponse tant que celle ci est incorrect
                while(length(direction_test) == 0 || length(direction_test) > 1){
                    println(RED + "Tu dois rentrer un déplacement !" + WHITE);
                    println(RED+"Haut = "+JAUNE+" D "+WHITE+" \n "+RED+"Bas = "+JAUNE+"S"+WHITE+" \n "+RED+"Gauche = "+JAUNE+"Q"+WHITE+" \n "+RED+"Droite = "+JAUNE+"D"+ "\n" + WHITE);
                    delay(TEMPS_PAUSE);
                    direction_test = "" + readString().toLowerCase();
                    println("");
                    }
            
            //Sinon on continu
            }else{
                println("On continue alors ! Tu me donnes une direction ?");
                delay(TEMPS_PAUSE);
                direction_test = "" + readString().toLowerCase();

                //On redemande une réponse tant que celle ci est incorrect
                while(length(direction_test) == 0 || length(direction_test) > 1 || charAt(direction_test,0) != 'z' || charAt(direction_test,0) != 's' || charAt(direction_test,0) != 'q' || charAt(direction_test,0) != 'd' || charAt(direction_test,0) != 'f'){
                    println(RED + "Tu dois rentrer un déplacement correct !" + WHITE);
                    println(RED+"Haut = "+JAUNE+" D "+WHITE+" \n "+RED+"Bas = "+JAUNE+"S"+WHITE+" \n "+RED+"Gauche = "+JAUNE+"Q"+WHITE+" \n "+RED+"Droite = "+JAUNE+"D"+ "\n" + RED + "Sauvegarder et quitter = " + JAUNE + "F" + WHITE);
                    delay(TEMPS_PAUSE);
                    direction_test = readString().toLowerCase();
                    println("");
                    }
                }
            direction = charAt(direction_test,0);
        }
        
        //On vérifie si le deplacement dans la direction choisis déplace au moin une cases
        while (!deplacement_test(grille,joueur,direction)){
            println(RED + "Déplacement impossible, recommence !" + WHITE);
            delay(TEMPS_PAUSE);
            println("");
            direction = readChar();
            }
            question = Question_reponse(partie);

        //On vérifie si la réponse du joueur est correct
        if(!reponse_correct(question)){
            println("");
            println("Dommage, la réponse était " + CYAN +Bonne_reponse(question)+WHITE + " :(" + "\n");
            delay(TEMPS_PAUSE);
            joueur.nb_vie = joueur.nb_vie - 1;

            //On vérifie le nombre de vie du joueur et lui indiqué s'il n'en a plus
            if(joueur.nb_vie == 0){
                println(RED + "Attention"+ WHITE + ", encore une erreur et c'est"+ RED + "GAME OVER" + WHITE);
                delay(TEMPS_PAUSE);

            //On indique le nombre de vie restante du joueur
            }else if(joueur.nb_vie > 0) {
                println("Il te reste " + CYAN +joueur.nb_vie + WHITE+" vie \n" );
                delay(TEMPS_PAUSE);
            }
        
        //Si la réponse est correct, on effectue le déplacement
        }else{
            println("");
            println("Bien joué " +CYAN +joueur.Nom_Joueur + WHITE+ " !");
            println("");
            delay(TEMPS_PAUSE);

            //Si la direction est droite ou gauche
            if(direction == 'd' || direction == 'q'){
                
                //On boucle pour decaler toutes les lignes
                for (int lig = 0; lig < 4; lig ++){
                    decaler_ligne(grille, lig, direction,joueur);
                }
            }

            else{            
                //Sinon on boucle pour decaler toutes les colonnes
                for (int col = 0; col < 4; col ++){
                   decaler_colonne(grille, col, direction,joueur);
                }

            }
        }
                
    }       
        
    //Vérifie si le déplacement indiqué est correct
    boolean deplacement_correct(String deplacement){
        if (length(deplacement) == 1 && charAt(deplacement,0) == 'f'|| charAt(deplacement,0) == 'd' || charAt(deplacement,0) == 'q' || charAt(deplacement,0) == 'z' || charAt(deplacement,0) == 's'){
            return true;
        }
        else{
            return true;
        }
    }

    //Fonction qui s'occupe de décaler les cases lignes par lignes
    void decaler_ligne(Case[][] grille,int lig,char direction,Joueur joueur){
        
        //Si direction = droite, on parcourt la ligne de droite à gauche(on retire 1 à la colonne)
        if(direction == 'd'){
            
            //Si la case contient un nombre, on regarde pour la decaler
            for (int col = 3; col >= 0 ; col --){
                if (grille[lig][col].type == Type.NOMBRE){
                    decaler(grille, col,lig,direction,joueur);
                }
            }
        
        //Si direction = gauche, on parcourt la ligne de gauche à droite(on ajoute 1 à la colonne)
        } else{
            
            //Si la case contient un nombre, on regarde pour la decaler
            for (int col = 0; col < NB_COLS ; col ++){
                if (grille[lig][col].type == Type.NOMBRE){
                    decaler(grille, col,lig,direction,joueur);
                }
            }
        }
    }

    //Fonction qui s'occupe de décaler les cases colonnes par colonnes
    void decaler_colonne(Case[][] grille,int col,char direction,Joueur joueur){
        
        //Si direction = haut, on parcourt la colonne de haut en bas(on ajoute 1 à la ligne)
        if(direction == 'z'){
            
            //Si la case contient un nombre, on regarde pour la decaler
            for (int lig = 0; lig < NB_LIGNES ; lig ++){
                if (grille[lig][col].type == Type.NOMBRE){
                    decaler(grille, col,lig,direction,joueur);
                }
            }
        
        //Si direction = bas, on parcourt la ligne de bas en haut(on retire 1 à la ligne)
        } else{
            
            //Si la case contient un nombre, on regarde pour la decaler
            for (int lig = 3; lig >= 0 ; lig --){
                if (grille[lig][col].type == Type.NOMBRE){
                    decaler(grille, col,lig,direction,joueur);
                }
            }
        }
    }


    //Decale une seul et unique case selon la direction selon
    void decaler(Case[][] grille,int col,int lig,char direction, Joueur joueur){
        int col_suivante = col;
        int lig_suivante = lig;
    
        //Si la direction est droite
        if(direction == 'd'){
            
            //Tant que le voisin de droite est vide et que l'on est pas au bord de droite (3)
            while(voisin_droite_vide(grille,lig,col_suivante) && col < 4){
                //On avance la colonne de la case
                col_suivante ++ ;
            }
        }

        //Si la direction est gauche
        if(direction == 'q'){
            
            //Tant que le voisin de gauche est vide et que l'on est pas au bord de gauche (0)
            while(voisin_gauche_vide(grille,lig,col_suivante) && col >= 0){

                //On avance la colonne de la case
                col_suivante -- ;
            }
        }

        //Si la direction est haut
        if(direction == 'z'){
            
            //Tant que le voisin du haut est vide et que l'on est pas au bord haut (0)
            while(voisin_haut_vide(grille,lig_suivante,col) && lig >= 0){

                //On avance la colonne de la case
                lig_suivante -- ;
            }    
        }

        //Si la direction est bas
        if(direction == 's'){
            
            //Tant que le voisin du bas est vide et que l'on est pas au bord bas (3)
            while(voisin_bas_vide(grille,lig_suivante,col) && lig < 4){

                //On avance la colonne de la case
                lig_suivante ++ ;
            }    
        }
        
        
        //On modifie les cases si elles ont bougés
        if(col_suivante != col || lig_suivante != lig){
            grille[lig_suivante][col_suivante].num =  grille[lig][col].num;
            grille[lig_suivante][col_suivante].type = Type.NOMBRE;
            grille[lig][col] = newVide(grille[lig][col]);
        }
    
        //Vérifie si la fusion est possible et fait la fusion si possible
        if(fusion_possible(grille,lig_suivante,col_suivante,direction)){
            fusion(grille,lig_suivante,col_suivante,direction,joueur);
        }
    }

    //Calcul si la fusion est possible en fonction de la direction
    boolean fusion_possible(Case[][] grille, int lig, int col, char direction){
        
        //Vérifie si le voisin de droite est identique à la case choisis
        if (direction == 'd'){
            if (col + 1 < 4 && grille[lig][col + 1].type == Type.NOMBRE && grille[lig][col + 1].num == grille[lig][col].num){
                return true;
            }
        }

        //Vérifie si le voisin de gauche est identique à la case choisis
        else if (direction == 'q'){
            if (col - 1 >= 0 && grille[lig][col - 1].type == Type.NOMBRE && grille[lig][col - 1].num == grille[lig][col].num){
                return true;
            }
        }

        //Vérifie si le voisin du haut est identique à la case choisis
        else if (direction == 'z'){
            if (lig - 1 >= 0 && grille[lig - 1][col].type == Type.NOMBRE && grille[lig - 1][col].num == grille[lig][col].num){
                return true;
            }
        }

        //Vérifie si le voisin du bas est identique à la case choisis
        else {
            if (lig + 1 < 4 && grille[lig + 1][col].type == Type.NOMBRE && grille[lig + 1][col].num == grille[lig][col].num){
                return true;
            }
        }
        return false;

    }

    //Effectue la fusion en fonction de la direction
    void fusion(Case[][] grille, int lig, int col, char direction, Joueur joueur){
        
        //Si la direction est droite, on remplace la case actuelle par une case vide et on double la case qui était à sa droite
        if (direction == 'd'){
            joueur.score = joueur.score + grille[lig][col].num;
            grille[lig][col + 1].type = Type.NOMBRE;
            grille[lig][col + 1].num = grille[lig][col].num + grille[lig][col].num ;
            grille[lig][col] = newVide(grille[lig][col]);
        }

        //Si la direction est gauche, on remplace la case actuelle par une case vide et on double la case qui était à sa gauche
        else if (direction == 'q'){
            joueur.score = joueur.score + grille[lig][col].num;
            grille[lig][col - 1].type = Type.NOMBRE;
            grille[lig][col - 1].num = grille[lig][col].num + grille[lig][col].num ;
            grille[lig][col] = newVide(grille[lig][col]);
        }

        //Si la direction est haut, on remplace la case actuelle par une case vide et on double la case qui était au dessus d'elle
        else if (direction == 'z'){
            joueur.score = joueur.score + grille[lig][col].num;
            grille[lig - 1][col].type = Type.NOMBRE;
            grille[lig - 1][col].num = grille[lig][col].num + grille[lig][col].num ;
            grille[lig][col] = newVide(grille[lig][col]);
        }

        //Si la direction est bas, on remplace la case actuelle par une case vide et on double la case qui était au dessous d'elle
        else {
            joueur.score = joueur.score + grille[lig][col].num;
            grille[lig + 1][col].type = Type.NOMBRE;
            grille[lig + 1][col].num = grille[lig][col].num + grille[lig][col].num ;
            grille[lig][col] = newVide(grille[lig][col]);
        }
    }

    //Verifie si le voisin de droite est vide
    boolean voisin_droite_vide(Case[][] grille,int lig,int col_suivante){
        boolean est_vide = false;
        if(col_suivante + 1 < 4){
            if(grille[lig][col_suivante + 1].type == Type.VIDE){
                est_vide = true;
            }
        }
        return est_vide;
    }

    //Verifie si le voisin de gauche est vide
    boolean voisin_gauche_vide(Case[][] grille,int lig,int col_suivante){
        boolean est_vide = false;
        if(col_suivante - 1 >= 0){
            if(grille[lig][col_suivante - 1].type == Type.VIDE){
                est_vide = true;
            }
        }
        return est_vide;
    }

    //Verifie si le voisin du haut est vide
    boolean voisin_haut_vide(Case[][] grille,int lig_suivante,int col){
        boolean est_vide = false;
        if(lig_suivante - 1 >= 0){
            if(grille[lig_suivante - 1][col].type == Type.VIDE){
                est_vide = true;
            }
        }
        return est_vide;
    }

    //Verifie si le voisin du bas est vide
    boolean voisin_bas_vide(Case[][] grille,int lig_suivante,int col){
        boolean est_vide = false;
        if(lig_suivante + 1 < 4){
            if(grille[lig_suivante + 1][col].type == Type.VIDE){
                est_vide = true;
            }
        }
        return est_vide;
    }

    ////////////////////////////// TEST Déplacement//////////////////////////////

    //Vérifie si le déplacent choisis est possible et utile (Si le déplacement ne bouge aucune case il est considéré comme inccorect)
    boolean deplacement_test(Case[][] grille, Joueur joueur, char direction) {
            if(direction == 'd' || direction == 'q'){
                
                //On boucle pour decaler les lignes
                for (int lig = 0; lig < 4; lig ++)
                    if (decaler_ligne_test(grille, lig, direction)){
                        return true;
                    }
            }

            else{            
                
                //On boucle pour decaler les colonnes
                for (int col = 0; col < 4; col ++)
                    if (decaler_colonne_test(grille, col, direction)){
                        return true;
                    }

            }
            return false;
        }

    //Vérifie si le cécalage au seins de la ligne est possible
    boolean decaler_ligne_test(Case[][] grille,int lig,char direction){
        
        //Si direction = droite, on parcourt la ligne de droite à gauche(on retire 1 à la colonne)
        if(direction == 'd'){
            for (int col = 3; col >= 0 ; col --){

                //Si la case contient un nombre, on regarde pour la decaler
                if (grille[lig][col].type == Type.NOMBRE){
                    if(decaler_test(grille, col,lig,direction)){
                        return true;
                    }
                }
            }
        
        //Si direction = gauche, on parcourt la ligne de gauche à droite(on ajoute 1 à la colonne)
        } else{
            for (int col = 0; col < NB_COLS ; col ++){

                //Si la case contient un nombre, on regarde pour la decaler
                if (grille[lig][col].type == Type.NOMBRE){
                    if(decaler_test(grille, col,lig,direction)){
                        return true;
                    }
                }
            }
        }
        return false;
    }


    //Vérifie si le décalage au seins de la colonne est possible
    boolean decaler_colonne_test(Case[][] grille,int col,char direction){
        
        //Si direction = haut, on parcourt la colonne de haut en bas(on ajoute 1 à la ligne)
        if(direction == 'z'){
            for (int lig = 0; lig < NB_LIGNES ; lig ++){
                
                //Si la case contient un nombre, on regarde pour la decaler
                if (grille[lig][col].type == Type.NOMBRE){
                    if(decaler_test(grille, col,lig,direction)){
                        return true;
                    }
                }
            }
        
        //Si direction = bas, on parcourt la ligne de bas en haut(on retire 1 à la ligne)
        } else{
            for (int lig = 3; lig >= 0 ; lig --){
                
                //Si la case contient un nombre, on regarde pour la decaler
                if (grille[lig][col].type == Type.NOMBRE){
                    if(decaler_test(grille, col,lig,direction)){
                        return true;
                    }
                }
            }
        }
        return false;
    }

    //Vérifie si le décalage de la case est possible
    boolean decaler_test(Case[][] grille,int col,int lig,char direction){
        int col_suivante = col;
        int lig_suivante = lig;
    
        //Si la direction est droite
        if(direction == 'd'){
            
            //Tant que le voisin de droite est vide et que l'on est pas au bord de droite (3)
            while(voisin_droite_vide(grille,lig,col_suivante) && col < 4){
                //On avance la colonne de la case
                col_suivante ++ ;
            }
        }

        //Si la direction est gauche
        if(direction == 'q'){
            
            //Tant que le voisin de gauche est vide et que l'on est pas au bord de gauche (0)
            while(voisin_gauche_vide(grille,lig,col_suivante) && col >= 0){

                //On avance la colonne de la case
                col_suivante -- ;
            }
        }

        //Si la direction est haut
        if(direction == 'z'){
            
            //Tant que le voisin du haut est vide et que l'on est pas au bord haut (0)
            while(voisin_haut_vide(grille,lig_suivante,col) && lig >= 0){

                //On avance la colonne de la case
                lig_suivante -- ;
            }    
        }

        //Si la direction est bas
        if(direction == 's'){
            
            //Tant que le voisin du bas est vide et que l'on est pas au bord bas (3)
            while(voisin_bas_vide(grille,lig_suivante,col) && lig < 4){

                //On avance la colonne de la case
                lig_suivante ++ ;
            }    
        }
        
        
        //On renvoie true si les cases on bougé
        if(col_suivante != col || lig_suivante != lig){
            return true;
        }

        //On vérifie si la fusion est possible et on renvoie true si possible false sinon
        if(fusion_possible(grille,lig_suivante,col_suivante,direction)){
            return true;
        }
        return false;
    }


    //Vérifie si un déplacement est encore possible, si le joueur à atteint nombre limite ou si le joueur n'a plus de vie
    boolean test_partie_fini (Case[][] grille, Joueur joueur){
        if(joueur.nb_vie < 0){
            return true;
        }
        
        else if (test_2048(grille,joueur)){
            return true;
        } 
        else if(!test_toujours_deplacement(grille,joueur)){
            return true;
        }
        return false;
    }

    //Vérifie si un déplacement est encore possible
    boolean test_toujours_deplacement(Case[][] grille, Joueur joueur){
        if (deplacement_test(grille,joueur,'d')){
            return true;
        
        }else if (deplacement_test(grille,joueur,'q')){
            return true;
        
        }else if (deplacement_test(grille,joueur,'z')){
            return true;
        
        }else if (deplacement_test(grille,joueur,'s')){
            return true;
        }
        
        return false;
    }

    //Vérifie si un nombre limite est apparu dans le case
    boolean test_2048 (Case[][] grille, Joueur joueur){
        for(int lig = 0; lig < NB_LIGNES; lig ++){
            for(int col = 0; col < NB_COLS; col ++){
                if (grille[lig][col].num == joueur.limite){
                    return true;
                }
            }  
        }
        return false;
    }

    ////////////////////////////// AFFICHAGE //////////////////////////////



    //Transforme le tableau en String pour l'afficher par la suite 
    String toString(Case[][] grille){
        String res = "";
        for (int i = 0;i < length(grille,1); i ++){
            for (int j = 0; j <length(grille,2);j++){
                res += toString(grille[i][j]) + " ";
            }	    
            res+= "\n";
            res+= "\n";
        }
        res+= "\n";
        return res;
    
    }
    //Transforme une cases en String pour l'afficher par la suite
    String toString(Case case_choisis){
		if (case_choisis.type == Type.VIDE) {
			return "~   ";
		}
		else{
            if(case_choisis.num < 10){
                return CYAN + case_choisis.num + "   " + WHITE;
            } else if(case_choisis.num < 100){
                return CYAN + case_choisis.num + "  " + WHITE;
            }else if(case_choisis.num < 1000){
                return CYAN + case_choisis.num + " " + WHITE;
            }else {
                return CYAN + case_choisis.num + "" + WHITE;
            }
        }
    }

    //Affichage du contenu d'un fichier texte d'après son chemin
    void afficherFichier(String chemin){
        File unTexte = newFile(chemin);

	    //Stockage dans une variable de la ligne suivante dans le fichier
        while(ready(unTexte)){
	        //affichage du contenu de la ligne suivante
	        println(RED + readLine(unTexte) + WHITE);
	    }
    }

    ////////////////////////////// Sauvegarde//////////////////////////////
    
    //Transforme un fichier CSV en tableau à deux dimension
    String[][] CSVToTab(CSVFile save){
        String[][] saveString = new String[rowCount(save)][columnCount(save)];
        for (int i = 0; i < rowCount(save); i ++){
            for (int j = 0; j < columnCount(save); j ++){
                saveString[i][j] = "" + getCell(save, i, j);
            }
        }
        return saveString;
    }

    //On sauvegarde tableau réprésentant le fichier CSV trié dans l'ordre croissant avec le nom et score des joueurs
    void Sauvegarde(CSVFile save,int score,String prenom,String[][] saveString,String save_chemin){
        int indice = 0;
        int indice_min = 0;

        //On parcourt le tableau jusqu'à soit trouver le prénom
        while(!saveString[indice_min][0].equals(prenom) && indice_min < length(saveString) - 1){ //CHECK
            indice_min = indice_min + 1;
            }
        
        //On parcourt le tableau jusqu'à soit trouver le score inférieur
        while(stringToInt(saveString[indice][1]) >= score && indice < indice_min){ //CHECK
            indice = indice + 1;
        }

        //Si l'indice qu'on à est déja égal au prénom, alors le score est supérieeur donc pas de meilleur score
        if (indice >= indice_min){   //CHECK
            println(MAGENTA + "Ton score est de "+ CYAN + score + MAGENTA + "\n \nDommage, la dernière fois ton dernier score était de " + CYAN +saveString[indice_min][1] + MAGENTA + "\n \nTu feras mieux la prochaine fois ! \n \n");
        }
        
        //Sinon c'est que le nouveau score est meeilleur
        else {
            
            //On reparcourt le tableau jusqu'à trouvé un élémeent stricteement supérieeur au  et on le décale 
            while(stringToInt(saveString[indice_min][1]) < score && indice_min > indice ){
                saveString[indice_min][0] = saveString[indice_min - 1][0];
                saveString[indice_min][1] = saveString[indice_min - 1][1];
                indice_min = indice_min - 1;
            }
            indice_min = indice_min + 1;
            saveString[indice][0] = prenom;
            saveString[indice][1] = "" + score;
        }
        saveCSV(saveString,save_chemin);
        println(JAUNE + toString(saveString) + WHITE);
    }

        //On affiche le tableau des scores (La sauvegarde trié par ordre de score)
        String toString(String[][] grille){
            String res = CYAN + "||||||||| HIGH SCORE |||||||||"+ WHITE + "\n\n";
            for (int i = 0;i < length(grille,1) && i < 10; i ++){
                for (int j = 0; j <length(grille,2);j++){
                    if(j == 1){
                        for(int k = 12; k > length(grille[i][0]); k --){
                        res += " ";
                        }
                    }
                    res +="     " + JAUNE + grille[i][j] + WHITE +"";
                }	    
                res+= "\n";
                res+= "\n";
            }
            res+= "\n";
            return res;
        }


    //Transforme un tableau en chaine de caractère pour l'afficher par la suite
    String TabToSring(String[][] saveString, CSVFile save){
        String afficher = "";
        for (int i = 0; i < rowCount(save); i ++){
            for (int j = 0; j < columnCount(save); j ++){
                afficher = afficher + saveString[i][j] + " ";
            }
        afficher = afficher + "\n";
        }
        return afficher;
    }

    //Fonction qui calcul le meilleurs score d'un joueur (Soit en allant le chercher dans la sauvegarde ou en l'actualisant à 0)
    int high_score(String[][] saveString,String prenom){
        int score = 0;
        int indice = 0;
        //On parcourt le tableau jusqu'à soit trouver le prénom
        while(!saveString[indice][0].equals(prenom) && indice < length(saveString) - 1){ //CHECK
            indice = indice + 1;
            }
        if(saveString[indice][0].equals(prenom)){
            score = stringToInt(saveString[indice][1]);
        }
        return score;
    }

    //Fonction qui affiche les première phrase du jeux
    void affichage_debut(){
        clearScreen();
        println("Bienvenu dans... \n");
        delay(TEMPS_PAUSE);
        clearScreen();
        afficherFichier(multi48);
        delay(TEMPS_PAUSE);
        clearScreen();
        println (Regle + "\n");
        delay(TEMPS_PAUSE);
        println("Choisissez votre classe parmi " + JAUNE +"CP"+WHITE +"," +JAUNE +" CE1"+WHITE+ "," +JAUNE +" CE2" +WHITE+ "," +JAUNE +" CM1 " +WHITE +"et " +JAUNE +"CM2 " + WHITE);
        delay(TEMPS_PAUSE);
    }

    ////////////////////////////// PARTIE //////////////////////////////

    //Lancement de la partie
    //Effectue le coup d'un joueur et l'applique à la grille
    void jouer(Case[][] grille,Joueur joueur,Partie partie){
        deplacement(grille,joueur,partie);
        grille = apparition_alea(grille, partie);
        clearScreen();
        println(toString(grille));
        println("Ton score est de " + CYAN +joueur.score + WHITE);
        if (joueur.score > highScore){
            highScore = joueur.score;
        }
        println("Ton score record est de "+ CYAN + highScore + WHITE);
    }

    //Lance la partie
    void algorithm(){
        
        //On créait une grille un joueur et une partie
        Joueur joueur = newJoueur();
        Partie partie = newPartie();
        Case[][] grille = new Case[NB_LIGNES][NB_COLS];

        //On initialise la grille
        grille = initialiser(grille);
        affichage_debut();
        delay(TEMPS_PAUSE);
        niveau(partie);

        //On charge la sauvegarde pour trouver le meilleur score du joueur
        CSVFile save = loadCSV("../ressources/Score/Score" +  partie.niveau + ".csv");
        String chemin_save = "../ressources/Score/Score" +  partie.niveau + ".csv";
        String[][] saveString = CSVToTab(save);
        highScore = high_score(saveString,joueur.Nom_Joueur);
        clearScreen();
        println(toString(grille));
        
        //On continue jusqu'à ce que la partie soit finie
        while(!test_partie_fini(grille,joueur) && !partie_fini){
            jouer(grille,joueur,partie);
        }

        //On affiche un GAME OVER ainsi que le tableau des scores
        clearScreen();
        afficherFichier(GAMEOVER);
        delay(TEMPS_PAUSE);
        clearScreen();
        Sauvegarde(save,joueur.score,joueur.Nom_Joueur,saveString,chemin_save);
        delay(TEMPS_PAUSE);
        println( MAGENTA +"Fin de partie, j'espère que tu t'es bien amusé ! \n\n\n" + WHITE);
        delay(TEMPS_PAUSE);
    }
}

