#WorkWorkCar

C'est bon normalement j'ai fini les chomeurs. Sachez que je vous emmerde. 

Bien cordialement, la direction.
