function openNav() {
    document.getElementById("sideNav").style.width = "270px";
}

function closeNav() {
    document.getElementById("sideNav").style.width = "0";
}